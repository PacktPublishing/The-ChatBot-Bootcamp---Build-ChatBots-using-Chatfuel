const ejs = require('ejs');

module.exports.datePicker = async event => {
  const {
    uid,
    bot_id,
    chatfuel_token,
    chatfuel_block_name
  } = event.queryStringParameters;

  const body = await ejs.renderFile('./templates/datepicker.ejs', {
    data: {
      uid,
      bot_id,
      chatfuel_token,
      chatfuel_block_name
    }
  });

  return {
    statusCode: 200,
    body,
    headers: {
      "Content-Type": "text/html",
      "X-Frame-Options": "ALLOW-FROM https://www.messenger.com/",
      "X-Frame-Options": "ALLOW-FROM https://www.facebook.com/"
    }
  }
};