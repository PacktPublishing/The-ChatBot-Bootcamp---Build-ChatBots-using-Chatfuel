'use strict';
const AWS = require('aws-sdk');
const dynamoDb = new AWS.DynamoDB.DocumentClient();

const generatePolicy = (principalId, Effect, Resource) => {
  if (Effect && Resource) {
    return {
      principalId,
      policyDocument: {
        Version: '2012-10-17',
        Statement: [{
          Action: 'execute-api:Invoke',
          Effect,
          Resource
        }]
      }
    }
  }

  return {
    principalId
  }
}

module.exports.approve = (event, context, callback) => {
  if (!event.queryStringParameters || !event.queryStringParameters.access_token) {
    return callback('Unauthorized');
  }

  dynamoDb.get({
    TableName: 'authorizedUsers',
    Key: {
      id: event.queryStringParameters.access_token
    }
  }, (errors, result) => {
    if (errors) {
      return callback(null, generatePolicy('chatfuel', 'Deny', event.methodArn));
    }

    if (result.Item && result.Item.access) {
      return callback(null, generatePolicy('chatfuel', 'Allow', event.methodArn));
    } else {
      return callback(null, generatePolicy('chatfuel', 'Deny', event.methodArn));
    }
  });
};