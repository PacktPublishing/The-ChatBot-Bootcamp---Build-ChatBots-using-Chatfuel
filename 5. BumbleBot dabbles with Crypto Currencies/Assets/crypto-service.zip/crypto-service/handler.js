'use strict';

const axios = require('axios');
const qs = require('querystring');
const formatCurrency = require('format-currency');
const nlp = require('./lib/nlp');
const {
  timestamp,
  formatTime,
  getSymbol,
  respond
} = require('./lib/utils');

module.exports.getSymbolFromMessage = async event => {
  const {
    user_query,
    resolved_block,
    failed_block
  } = qs.parse(event.body);

  try {
    const getCurrency = await nlp(user_query, ['cryptocurrency']);
    if (getCurrency.length !== 0) {
      const symbol = await getSymbol(getCurrency[0].value);

      if (symbol) {
        return respond(null, {
          set_attributes: {
            currency_symbol: symbol.symb,
            currency: symbol.coin
          },
          redirect_to_blocks: [resolved_block]
        });
      }

      return respond(null, {
        redirect_to_blocks: [failed_block]
      });
    }

    return respond(null, {
      redirect_to_blocks: [failed_block]
    });
  } catch ({
    message
  }) {
    return respond(message);
  }
}

module.exports.getTimeFromQuery = async event => {
  const {
    user_requested_date,
    block_name,
    redirect_to
  } = qs.parse(event.body);

  if (user_requested_date) {
    const getDate = await nlp(user_requested_date, ['datetime']);

    if (getDate.length > 0) {
      return timestamp(getDate[0].value) <= timestamp() ? respond(null, {
        set_attributes: {
          computed_date: timestamp(getDate[0].value)
        },
        redirect_to_blocks: [redirect_to]
      }) : respond(null, {
        messages: [{
          text: "I wish I could just get that DeLorean and get you those rates from the future. For now, I can only dive into the past for you! Try picking a historical date!"
        }],
        redirect_to_blocks: [block_name]
      });
    } 

    return respond(null, {
      messages: [{
        text: "Hmm, I didn't quite get that. Try typing in a date again..."
      }],
      redirect_to_blocks: [block_name]
    });
  }

  return respond(null, {
    messages: [{
      text: "Hmm, I didn't quite get that. Try typing in a date again..."
    }],
    redirect_to_blocks: [block_name]
  });
}

module.exports.crypto = async event => {
  const {
    currency,
    currency_symbol,
    computed_date,
    output_currency,
    reset_block
  } = qs.parse(event.body);

  const formattingOpts = {
    format: '%c %v',
    code: output_currency
  }

  try {
    if (computed_date) {
      //const getDate = await nlp(computed_date, ['datetime']);
      const result = await axios.get('https://min-api.cryptocompare.com/data/pricehistorical', {
        params: {
          fsym: currency_symbol,
          tsyms: output_currency,
          ts: computed_date
        }
      });

      

      return respond(null, {
        messages: [{
          text: `{{ first name }}, the price of 1 ${currency} on ${formatTime(computed_date)} was ${formatCurrency(result.data[currency_symbol][output_currency], formattingOpts)}`
        }],
        redirect_to_blocks: [reset_block]
      });
    } else {
      const result = await axios.get('https://min-api.cryptocompare.com/data/price', {
        params: {
          fsym: currency_symbol,
          tsyms: output_currency
        }
      });

      return respond(null, {
        messages: [{
          text: `{{ first name }}, at the moment ${currency} is trading for ${formatCurrency(result.data[output_currency], formattingOpts)}`
        }],
        redirect_to_blocks: [reset_block]
      });
    }

  } catch ({
    message
  }) {
    return respond(message);
  }
};